const path = require("path");
const fs = require("fs");

// Torrent
const Torrent = require(path.join(__dirname, "js", "download.js"));
const torrentManager = new Torrent();

const express = require("express");
const router = express.Router();

// app module
const ata = require(path.join(__dirname, "js", "ata.js"));

// Save
const { prss } = require(path.join(
    __dirname,
    "../../../",
    "container",
    "save",
    "process.js"
));

const routes = [
    {
        method: 'get',
        path: '/home',
        handler: (req, res) => {
            // datos del package
            let pack = ata._json("read", path.join(__dirname, "package.json"));

            // render
            res.render(path.join(__dirname, "views", "home"), {
                pack: pack,
            });
        }
    },
    {
        method: 'get',
        path: '/d/:magnet',
        handler: async (req, res) => {
            const ruta = await torrentManager.searchFolderAsync();
            if (ruta !== null) {
                const torrentResp = await torrentManager.addTorrent(
                    ata.base64ToCadena(req.params.magnet),
                    ruta
                );

                if (torrentResp == "exist_torrent") {
                    res.send(torrentResp);
                } else if (torrentResp == null) {
                    res.send("err_client");
                } else {
                    prss.addPrss("torrents", "/torrenthive/stopall");
                    res.send(torrentResp);
                }
            } else {
                res.send(false);
            }
        }
    },
    {
        method: 'get',
        path: '/openfile',
        handler: async (req, res) => {
            const ruta = await torrentManager.searchFileAsync();
            if (ruta) {
                res.json({ file: ruta });
            } else {
                res.send(false);
            }
        }
    },
    {
        method: 'get',
        path: '/action/:type/:hash',
        handler: async (req, res) => {
            const tipo = req.params;
            let resp = "no_act";
            if (tipo.type == "pause") {
                const act = await torrentManager.pauseTorrent(tipo.hash);
                resp = act;
            } else if (tipo.type == "stop") {
                const act = await torrentManager._stop(tipo.hash);
                resp = act;
            }
            res.send(resp);
        }
    },
    {
        method: 'get',
        path: '/svg/:name',
        handler: async (req, res) => {
            const contentType = "image/svg+xml";

            res.writeHead(200, { "Content-Type": contentType });

            const filePath = path.join(
                __dirname,
                "public",
                "svg",
                `${req.params.name}.svg`
            );
            const readStream = fs.createReadStream(filePath);

            readStream.pipe(res);
        }
    },
    {
        method: 'get',
        path: '/getdownload/:hash',
        handler: async (req, res) => {
            let send = torrentManager.getTorrentInfo(req.params.hash);
            if (send) {
                res.json(send);
            } else {
                res.send(false);
            }
        }
    },
    {
        method: 'get',
        path: '/list',
        handler: async (req, res) => {
            res.json(torrentManager.list);
        }
    },
    {
        method: 'get',
        path: '/stopall',
        handler: async (req, res) => {
            await torrentManager.stopAll();
            res.end();
        }
    },
    {
        method: 'get',
        path: '/os',
        handler: async (req, res) => {
            const disk_os = await ata.oSystem({ pc: req.query.reload === undefined ? false : req.query.reload });
            res.json(disk_os);
        }
    },
    {
        method: 'get',
        path: '/file/*',
        handler: async (req, res) => {
            //   let referer = req.headers.referer || req.headers.referrer;
            //   let ar = referer.split("/");

            const extName = path.extname(req.params[0]);

            // Tipos de contenido
            const contentTypes = {
                ".css": "text/css",
                ".js": "text/javascript",
                ".json": "application/json",
                ".png": "image/png",
                ".ico": "image/x-icon",
                ".jpg": "image/jpeg",
                ".svg": "image/svg+xml",
                ".mp3": "audio/mpeg", // Tipo de contenido para archivos mp3
                ".mp4": "video/mp4", // Tipo de contenido para archivos mp4
            };

            const contentType = contentTypes[extName] || "text/html";

            res.writeHead(200, { "Content-Type": contentType });

            const filePath = path.join(__dirname, "public", req.params[0]);
            const readStream = fs.createReadStream(filePath);

            readStream.pipe(res);
        }
    },
    {
        method: 'get',
        path: '/parsetorrent/:file',
        handler: async (req, res) => {
            try {
                res.send(ata.gettorrent(ata.base64ToCadena(req.params.file)));
            } catch (error) {
                res.send(false);
            }
        }
    }
    // ... otras rutas ...
];

module.exports = routes;
