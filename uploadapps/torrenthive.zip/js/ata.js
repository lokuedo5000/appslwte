const path = require('path');
const fs = require('fs');
const axios = require("axios");
// os
const os = require("os");
const si = require("systeminformation");
// torrent
const parseTorrent = require("parse-torrent");

class Ata {
    constructor() {
        this.paks = [];
        this.pc = {};
    }

    async _axios(url, data) {
        try {
            const response = await axios.get(url, { params: data });
            return response.data;
        } catch (error) {
            return error;
        }
    };

    _json(type, ruta) {
        if (type === "read") {
            try {
                const read = fs.readFileSync(ruta, 'utf-8');
                const result = JSON.parse(read);
                return result;
            } catch (error) {
                console.log({ err: error });
                return { err: error };
            }
        } else if (type === "save") {

        } else {
            return false;
        }
    }

    gettorrent(data) {
        const torrent = fs.readFileSync(path.join(data));
        const torrentfile = parseTorrent(torrent);

        return torrentfile;
    };

    base64ToCadena(cadena) {
        const buffer = Buffer.from(cadena, 'base64');
        return buffer.toString('utf-8');
    }

    loadApps(appsFolderPath) {
        const packageJsonFiles = [];

        // Leer el contenido del directorio de aplicaciones
        const files = fs.readdirSync(appsFolderPath);

        // Iterar a través de cada archivo en el directorio
        files.forEach(file => {
            const filePath = path.join(appsFolderPath, file);
            const stats = fs.statSync(filePath);

            // Verificar si es un directorio
            if (stats.isDirectory()) {
                // Buscar el archivo 'package.json' en el directorio de la app
                const packageJsonPath = path.join(filePath, 'package.json');

                // Verificar si el archivo 'package.json' existe
                if (fs.existsSync(packageJsonPath)) {
                    const packageJsonContent = fs.readFileSync(packageJsonPath, 'utf-8');
                    const packageJson = JSON.parse(packageJsonContent);
                    packageJson.fileJS = path.join(appsFolderPath, packageJson.name, packageJson.main);
                    packageJsonFiles.push(packageJson);
                }
            }
        });

        this.paks = packageJsonFiles;
    }

    async cpuInfo() {
        try {
            // Obtener información de la CPU
            const cpuData = await si.cpu();

            // Obtener información de la memoria
            const memData = await si.mem();

            // Obtener información del sistema de archivos
            const fsData = await si.fsSize();
            return {
                cpu: cpuData,
                memoria: memData,
                sistemaArchivos: fsData,
            };
        } catch (error) {
            console.error(error);
        }
    };

    async oSystem({pc = false}) {
        // Obtener información sobre la CPU
        if (pc) {
            this.pc = await this.cpuInfo();
        } else {
            const keysArray = Object.keys(this.pc);
            if (keysArray.length === 0) {
                this.pc = await this.cpuInfo();
            }
        }

        return {
            sistema: os.arch(),
            model: os.cpus()[0].model,
            memory: (os.totalmem() / 1024 / 1024 / 1024).toFixed(2),
            dispo: (os.freemem() / 1024 / 1024 / 1024).toFixed(2),
            nucleos: os.cpus().length,
            infoAvance: this.pc,
        };
    };
}

module.exports = new Ata();
