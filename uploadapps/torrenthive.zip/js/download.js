const { BrowserWindow, dialog } = require("electron");
const path = require('path');
const fs = require('fs');
const parseTorrent = require("parse-torrent");
const WebTorrent = require('webtorrent');

class Torrent {
  constructor() {
    this.clients = {};
    this.downloads = {};
    this.list = [];
    this.temp = {};
  }

  createTorrentClient(clientId, endtorrent, stop) {
    const id = clientId.slice(0, 6) === "client" ? clientId : `client${clientId}`;

    if (stop) {
      const client = this.clients[id];
      if (client) {
        client.destroy(() => {
          delete this.clients[id];
          this.list = this.list.filter(element => element !== clientId);
          delete this.downloads[clientId];

          console.log("delete:", id);
        });
      }
      return;
    }

    if (endtorrent) {
      const client = this.clients[id];
      if (client) {
        client.destroy(() => {
          delete this.clients[id];
        });
      }
      return;
    }

    if (this.clients[id]) {
      return this.clients[id];
    } else {
      this.clients[id] = new WebTorrent();
      return this.clients[id];
    }
  }

  async addTorrent(magnet, savePath, resume) {
    const torrentId = parseTorrent(magnet);
    const downloadPath = resume ? savePath : path.join(savePath, torrentId.infoHash);

    let buscar = this._search(this.list, torrentId.infoHash);

    if (buscar.length === 0) {
      this.list.unshift(torrentId.infoHash);
    }

    try {
      const client = this.createTorrentClient(torrentId.infoHash);
      if (!client) {
        console.log('Cliente de WebTorrent no encontrado.');
        return null;
      }

      const torrent = await client.add(magnet, { path: downloadPath });
      torrent.on('download', () => {
        this.updateTorrentData(torrentId.infoHash, torrent, magnet);
      });

      torrent.on('done', async () => {
        await this.updateTorrentDataEnd(torrentId.infoHash, torrent);
        this.createTorrentClient(torrentId.infoHash, true);
      });


      return {
        info: torrent.infoHash,
        name: torrent.name
      };
    } catch (error) {
      console.error(`Error en addTorrent:`, error);
      return null;
    }
  }

  async updateTorrentDataEnd(id, torrent) {
    this.downloads[id].lengthPeso = torrent.length;
    this.downloads[id].downloadSpeed = 0;
    this.downloads[id].uploadSpeed = 0;
    this.downloads[id].downloaded = torrent.length;
    this.downloads[id].progress = 100;
    this.downloads[id].numPeers = 0;
    this.downloads[id].numPeersToWire = 0;
    this.downloads[id].timeRemaining = 0;
    this.downloads[id].isPaused = false;
    this.downloads[id].isDone = true;
  }


  async updateTorrentData(id, torrent, magnet) {
    if (this.downloads[id] == undefined) {
      this.downloads[id] = {};
      this.downloads[id].infoHash = id;
      this.downloads[id].name = torrent.name;
      this.downloads[id].downloadPath = torrent.path;
      this.downloads[id].magnet = magnet;
    }

    this.downloads[id].lengthPeso = torrent.length;
    this.downloads[id].downloadSpeed = torrent.downloadSpeed;
    this.downloads[id].uploadSpeed = torrent.uploadSpeed;
    this.downloads[id].downloaded = torrent.downloaded;
    this.downloads[id].progress = this.getTorrentProgress(torrent);
    this.downloads[id].numPeers = torrent.numPeers;
    this.downloads[id].numPeersToWire = torrent.numPeersToWire;
    this.downloads[id].timeRemaining = torrent.timeRemaining;
    this.downloads[id].isPaused = torrent.paused;
    this.downloads[id].isDone = torrent.done;
  }


  async pauseTorrent(infoHash) {
    // verificar si esta en pausa
    let dataTemp = this.downloads[infoHash];
    if (dataTemp) {
      if (dataTemp.isPaused) {
        const res = await this.addTorrent(dataTemp.magnet, dataTemp.downloadPath, true);
        this.downloads[infoHash].isPaused = false;
        return res;
      }
    }
    // detener torrent
    const client = this.createTorrentClient(infoHash);
    const torrent = client.get(infoHash);

    if (torrent) {
      torrent.pause();
      await new Promise((resolve, reject) => {
        torrent.destroy(err => {
          if (err) {
            reject(err);
          } else {
            // Temp
            this.downloads[infoHash].isPaused = true;
            this.downloads[infoHash].downloadSpeed = 0;
            this.downloads[infoHash].uploadSpeed = 0;
            // Stop all
            this.createTorrentClient(infoHash, true);
            resolve();
          }
        });
      });

      return true;
    } else {
      return false;
    }
  }

  async _stop(infoHash) {
    // detener torrent
    const client = this.createTorrentClient(infoHash);
    const torrent = client.get(infoHash);

    if (torrent) {
      torrent.pause();
      await new Promise((resolve, reject) => {
        torrent.destroy(err => {
          if (err) {
            reject(err);
          } else {
            this.createTorrentClient(infoHash, null, true);
            resolve();
          }
        });
      });

      return true;
    } else {
      return false;
    }
  }


  getTorrentInfo(id) {
    const torrent = this.downloads[id];
    if (torrent) {
      return torrent;
    }
    return null;
  }

  getTorrentProgress(torrent) {
    return (torrent.downloaded / torrent.length * 100).toFixed(2);
  }

  async searchFolderAsync() {
    const result = await dialog.showOpenDialog(BrowserWindow.getFocusedWindow(), {
      properties: ['openDirectory']
    });

    if (!result.canceled) {
      return result.filePaths[0];
    }
    return null;
  }

  async searchFileAsync() {
    const result = await dialog.showOpenDialog(BrowserWindow.getFocusedWindow(), {
      properties: ['openFile'],
      filters: [{ name: 'Torrent Files', extensions: ['torrent'] }]
    });

    if (!result.canceled) {
      const torrentFilePath = result.filePaths[0];
      return torrentFilePath;
    }

    return null;
  }

  _search(array, query) {
    if (typeof query === "string") {
      return array.filter(item => item === query);
    } else if (typeof query === "number") {
      return array[query] || null;
    }
    return null;
  }
  async destroyClient(clientId) {
    return new Promise((resolve, reject) => {
      const id = clientId.slice(0, 6) === "client" ? clientId : `client${clientId}`;
      const client = this.clients[id];

      if (client) {
        client.destroy(() => {
          delete this.clients[id];
          // console.log("Destroyed:", id);
          resolve(true); // Cliente destruido con éxito
        });
      }
    });
  }

  async stopAll() {
    const destroyPromises = Object.keys(this.clients).map(clientId => this.destroyClient(clientId));
    await Promise.all(destroyPromises);
  }
}

module.exports = Torrent;
