class MIN {
    constructor() {
        this.intervals = {};
        this.pc = {};

        this._pc();
    }
    async _pc() {
        let data = await this.senddata(`/os`, "GET", {});
        this.pc = data;

        let dataFiles = this.pc.infoAvance.sistemaArchivos;
        for (let i = 0; i < dataFiles.length; i++) {
            const element = dataFiles[i];
            // set data pc
            const unidad = $(`<div class="inf-unidad">`).append(
                $(`<div class="icono-unidad blue icon-drive">`),
                $(`<div class="info-disck">`).append(
                    $(`<h6 class="title-unidad">Unidad (${element.fs})</h6>`),
                    $(`<div class="progress">`).append(
                        $(`<div class="determinate blue" style="width: ${element.use}%"></div>`)
                    ),
                    $(`<h6 class="title-disp">${this.getSizeII(element.available)} / ${this.getSizeII(element.size)}</h6>`),
                )
            );

            $('#unidad-all').append(unidad);
        }


    }
    // tamaño
    getElt(obj, tipo) {
        let search = $(obj);
        if (search.length == 1) {
            switch (tipo) {
                case "h":
                    return search.height();
                case "w":
                    return search.width();
                case "H":
                    return search.outerHeight(true);
                case "W":
                    return search.outerWidth(true);
                default:
                    return false;
            }
        } else {
            return false;
        }
    }
    newClass(obj, cls) {
        $(obj).addClass(cls);
    }
    removeClass(obj, cls) {
        $(obj).removeClass(cls);
    }
    setText(obj, text) {
        $(obj).text(text);
    }
    setHtml(obj, html) {
        $(obj).html(html);
    }

    init() {

        $(".page-all.active").slideDown("fast");
        $(".open-page").on("click", (e) => {
            const clcikBtn = e;
            const text = clcikBtn.target.getAttribute('href');

            if (text.slice(0, 1) == "#") {
                $(".page-all").slideUp("fast");
                $(text).slideDown("fast");
            }


            // verificar si esta en descargas
            if (text.slice(1) == "downloads") {
                this.createInterval("getDownloads", async () => {
                    let data = await this.senddata(`/list`, "GET", {});
                    this.crearList(data);
                }, 1000);
            } else {
                this.removeInterval("getDownloads");
            }

        }).bind(this);


        // verificar search
        $('#magnet_input').keyup((e) => {
            let val = e.target.value;
            if (this.isUri(val)) {

                this.dltClass(".search-btn", "icon-").then(() => {
                    $(".search-btn").addClass("icon-cloud-download");
                    $(".search-btn").attr("onclick", `min.down('${this.textToBase64(val)}')`);
                });

            } else {
                this.dltClass(".search-btn", "icon-").then(() => {
                    $(".search-btn").addClass("icon-dots-three-vertical");
                    $(".search-btn").attr("onclick", `min.searchFile()`);
                });
            }
        }).bind(this);



    }

    async searchFile() {
        let data = await this.senddata(`/openfile`, "GET", {});
        if (data) {
            const sendTorrent = await this.senddata(`/parsetorrent/${this.textToBase64(data.file)}`, "GET", {});

            // const mg = this.newMagnet(sendTorrent.name, sendTorrent.infoHash, sendTorrent.announce.join("\n"));

            if (sendTorrent == false) {
                M.toast({ html: 'No se puede obtener los datos' })
                return;
            }

            this.setText(".name-text-torrent", sendTorrent.name);
            this.setText(".infohash-text", sendTorrent.infoHash);
            this.setText(".peso-text", this.getSizeII(sendTorrent.length));

            $('#trackers-list').val(sendTorrent.announce.join("\n"));
            M.textareaAutoResize($('#trackers-list'));

            $('#magnet-list').val(this.newMagnet(sendTorrent.name, sendTorrent.infoHash, $('#trackers-list').val()));




            const itemsPerPage = 5;


            const customTemplate = item => {
                const listItem = document.createElement("li");
                listItem.classList.add("collection-item");
                const divs = document.createElement("div");
                divs.innerHTML = `<div>${item.name}<li class="secondary-content">${this.getSizeII(item.length)}</li></div>`;
                listItem.appendChild(divs);
                return listItem;
            };

            const pagination = new Pagination(sendTorrent.files, itemsPerPage, "pagination", "collection", customTemplate);
            pagination.update();

            $('#modal1').modal('open');

        }
    }

    // async searchFile() {
    //     const magnet = this.textToBase64($('#magnet-list').val());
    //     let data = await this.senddata(`/d/${magnet}`, "GET", {});
    //     console.log(data);
    // }

    isUri(url) {
        if (url.startsWith('magnet:?')) {
            const prefix = 'magnet:?xt=urn:btih:';
            const parts = url.split('&');

            for (const part of parts) {
                if (part.startsWith(prefix)) {
                    const infoHash = part.slice(prefix.length);
                    if (/^[0-9a-fA-F]{40}$/.test(infoHash)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    dltClass(elm, prefix) {
        return new Promise((resolve, reject) => {
            const classes = Array.from(document.querySelector(elm).classList);
            const classesToRemove = classes.filter(className => className.startsWith(prefix));
            classesToRemove.forEach(className => {
                document.querySelector(elm).classList.remove(className);
            });

            resolve(); // Resuelve la promesa cuando las clases se eliminan
        });
    }

    async crearList(list) {
        for (let i = 0; i < list.length; i++) {
            const element = list[i];
            const very = $(`#id_${element}`);
            if (very.length > 0) {
                let torrent = await this.senddata(`/getdownload/${element}`, "GET", {});
                if (torrent.isDone) {
                    $(`.ispause_${element}`).addClass("d-none");
                    $(`.delete_${element}`).addClass("d-none");
                }
                // Is Pause
                $(`.ispause_${element}`).text(torrent.isPaused === true ? "Continuar" : "Detener")
                // Name
                $(`.name_${element}`).text(torrent.name);
                // size
                $(`.downloaded_${element}`).text(this.getSizeII(torrent.downloaded === NaN ? 0 : torrent.downloaded));
                $(`.peso_${element}`).text(this.getSizeII(torrent.lengthPeso === NaN ? 0 : torrent.lengthPeso));

                // progress
                $(`.progress_${element}`).css("width", `${torrent.progress === NaN ? 0 : torrent.progress}%`);

                // Speed
                $(`.downloadSpeed_${element}`).text(this.getSizeII(torrent.downloadSpeed === NaN ? 0 : torrent.downloadSpeed));
                $(`.uploadSpeed_${element}`).text(this.getSizeII(torrent.uploadSpeed === NaN ? 0 : torrent.uploadSpeed));
            } else {
                const infDownloadDiv = $(`<div class="inf-download" id="id_${element}">`).append(
                    $(`<div class="icono-download red">`),
                    $(`<div class="info-download">`).append(
                        $(`<h6 class="title-download name_${element}">...</h6>`),
                        $(`<div class="info-speed-down">`).append(
                            $(`<h6 class="title-disp"><span class="downloaded_${element}">0 K</span> / <span class="peso_${element}">0 K</span></h6>`),
                            $(`<div class="sprt-line"></div>`),
                            $(`<h6 class="title-disp"><i class="icon-arrow-down-thick"></i> <span class="downloadSpeed_${element}">0 K</span> <i class="icon-arrow-up-thick"></i><span class="uploadSpeed_${element}">0 K</span></h6>`)
                        ),
                        $(`<div class="progress">`).append(
                            $(`<div class="determinate blue progress_${element}" style="width: 0%"></div>`)
                        ),

                        $(`<a class="waves-effect waves-light btn-small red sprt-btn ispause_${element}" onclick="min.actionTorrent('pause', '${element}')">Detener</a>`),

                        $(`<a class="waves-effect waves-light btn-small red sprt-btn delete_${element}" onclick="min.actionTorrent('stop', '${element}')">Cancelar</a>`)
                    )
                );

                $('#list-downloads').append(infDownloadDiv);
            }
        }
    }

    async actionTorrent(tipo, hash) {
        let data = await this.senddata(`/action/${tipo}/${hash}`, "GET", {});
        if (data) {
            if (tipo == "stop") {
                $(`#id_${hash}`).remove();
            }
        }
    }

    newMagnet(name, infoHash, trackersTextarea) {
        const trackersArray = trackersTextarea.split('\n').filter(Boolean);

        // Crear la parte del enlace con los trackers
        const trackerPart = trackersArray.map(tracker => `tr=${tracker}`).join("&");

        // Crear el enlace magnet con los trackers
        return `magnet:?xt=urn:btih:${infoHash}&dn=${name}&${trackerPart}`;
    }


    getSizeII(bytes) {
        const units = ["B", "KB", "MB", "GB", "TB"];
        let size = bytes;
        let unit = "B";

        for (let i = 0; i < units.length; i++) {
            if (size < 1024) {
                unit = units[i];
                break;
            }
            size /= 1024;
            size = Number(size).toFixed(2);
        }
        return size + " " + unit;
    }

    isEncoded(str) {
        try {
            return decodeURIComponent(str) !== str;
        } catch (error) {
            return false;
        }
    }

    uRI(str) {
        return this.isEncoded(str) ? decodeURIComponent(str) : str;
    }

    textToBase64(cadena) {
        const base64 = btoa(cadena);
        return base64;
    }

    base64ToText(cadena) {
        const text = atob(cadena);
        return text;
    }

    async senddata(url, method, data) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url: url,
                method: method,
                data: data,
                success: function (respuesta) {
                    resolve(respuesta);
                },
                error: function (error) {
                    reject(error);
                },
            });
        });
    }

    async down(mg) {
        const magnet = mg === undefined ? this.textToBase64($('#magnet-list').val()) : mg;
        let data = await this.senddata(`/d/${magnet}`, "GET", {});
        if (data !== false) {
            M.toast({ html: `Iniciando descarga - ${data.name}` })
        }else{
            M.toast({ html: `Descarga cancelada` });
        }
    }

    createInterval(name, callback, intervalTime) {
        if (this.intervals[name] == undefined) {
            const interval = setInterval(callback, intervalTime);
            this.intervals[name] = interval;
            return interval;
        }
    }

    pauseInterval(name) {
        const interval = this.intervals[name];
        if (interval) {
            clearInterval(interval);
        }
    }

    removeInterval(name) {
        this.pauseInterval(name);
        delete this.intervals[name];
    }

    async copyToClipboard(selector) {
        const element = document.querySelector(selector);
        const textToCopy = element.tagName === 'INPUT' || element.tagName === 'TEXTAREA' ? element.value : element.textContent;

        try {
            await navigator.clipboard.writeText(textToCopy);
            M.toast({ html: 'Texto copiado al portapapeles' });
        } catch (error) {
            M.toast({ html: 'Error al copiar el texto' });
        }
    }
}

const min = new MIN();